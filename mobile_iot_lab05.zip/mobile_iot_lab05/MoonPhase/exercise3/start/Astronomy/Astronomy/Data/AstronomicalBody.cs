﻿namespace Astronomy
{
    public class AstronomicalBody
    {
        public string Name { get; set; }
        public string Mass { get; set; }
        public string Circumference { get; set; }
        public string Age { get; set; }
        public string EmojiIcon { get; set; }
    }
}